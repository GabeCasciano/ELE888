function [g] = discriminant(a, y)
    g = a * y';
    
end


